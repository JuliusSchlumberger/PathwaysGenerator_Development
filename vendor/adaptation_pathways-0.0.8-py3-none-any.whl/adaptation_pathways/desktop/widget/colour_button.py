from PySide6 import QtCore, QtGui, QtWidgets
from PySide6.QtCore import Qt


class ColourButton(QtWidgets.QPushButton):

    colour_changed = QtCore.Signal(object)

    def __init__(self, *args, colour=None, **kwargs):
        super(ColourButton, self).__init__(*args, **kwargs)

        self._colour = None
        self._default = colour
        self.pressed.connect(self.onColourPicker)

        # Set the initial/default state.
        self.setColour(self._default)

    def setColour(self, colour):
        if colour != self._colour:
            self._colour = colour
            self.colour_changed.emit(colour)

        if self._colour:
            self.setStyleSheet("background-color: %s;" % self._colour)
        else:
            self.setStyleSheet("")

    def colour(self):
        return self._colour

    def onColourPicker(self):
        dialog = QtWidgets.QColorDialog(self)

        if self._colour:
            dialog.setCurrentColor(QtGui.QColor(self._colour))

        if dialog.exec_():
            self.setColour(dialog.currentColor().name())

    def mousePressEvent(self, e):
        if e.button() == Qt.RightButton:
            self.setColour(self._default)

        return super(ColourButton, self).mousePressEvent(e)

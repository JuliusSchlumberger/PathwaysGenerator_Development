"""
This module contains code that is shared between the plots that have a default layout.
"""
